import MySQLdb
from facepy import GraphAPI
from flask import Flask, render_template, request, url_for, redirect

app1 = Flask(__name__)

db=MySQLdb.connect(host="localhost",user="root",password="",db="faceapp")


@app1.route('/postagens')
def post():
	token = 'EAAGSCJKPuCwBAOUJaDtxbb6JcCb01siPqLb0ovhHSxdgnp0dc8JfeEKy7PZAEjo3ZC3ypbqmkRQWNhpizZBpZBvBFwZAAt5NPHnPZBmyPTPjxUVUyJiXgxw2vp9vpHQj7Kwlwm0OFbaGgh1qf7hGerZBeuyC17YArw4zAJKsZCZAHYZAuhQJENKIsd' 
	graph = GraphAPI(token)

	# Get my latest posts
	a=graph.get('me/posts')


	post = graph.get('me/posts')
	quase = post['data']  #pegará todas as infos de 'data', atributo do vetor post

	li = [] 
	lin = []
	
	for i in quase:
	    li.append(i)

	for j in range(len(li)):  #função de filtragem, aqui só passarão os posts que tem descrição
	    po = ""
	    if 'message' in li[j]:
	        po = li[j]
	        lin.append(po)


	mus=['anitta','ludmilla','spotify','deezer','billboard','baco','ariana grande', 'hino', 'música', 'álbum','cd','hit','mc','funk', 'forró','baile']
	pol=['ciro gomes','pt','lula','luladrão','bozo','bolsonaro','coiso','esquerdista','direitos','política']
	rec=['receita', 'bolo','pudim', 'sobremesa','jantar','almoço','prato','doce','salgado','suco','comida']

	id_u=1 #Só tem um usuário no banco de dados, que é eduarda, usuária de id 1
	bd = db.cursor()

	for h in range(len(lin)):
		for m in range(len(mus)): 	#AQUI EU DIGO QUE ESSE POST É UM POST SOBRE MÚSICA
			
			if mus[m] in lin[h]['message']:
				bd.execute('insert into post(usu,conteudo,post,data_post) values(%s,%s,%s,%s)', [id_u, lin[h]['message'],'Música',lin[h]['created_time']])
				db.commit()		

		for p in range(len(pol)): 	#AQUI EU DIGO QUE ESSE POST É UM POST SOBRE política
			if pol[p] in lin[h]['message']:
				bd.execute('insert into post(usu,conteudo,post,data_post) values(%s,%s,%s,%s)', [id_u, lin[h]['message'],'Política',lin[h]['created_time']])
				db.commit()	
				 			
		for r in range(len(rec)):
			#print(rec[r])
			#print("Acima está uma palavra chave classificadora de posts culinários")
			if rec[r] in lin[h]['message']:
				bd.execute('insert into post(usu,conteudo,post,data_post) values(%s,%s,%s,%s)', [id_u,lin[h]['message'],'Receita',lin[h]['created_time']])
				db.commit()	


	return render_template('postagens.html', lin=lin, id_u=id_u, mus=mus, pol=pol, rec=rec )

@app1.route('/')
def index():
	return render_template('index.html')
