drop schema if exists faceapp;
create schema if not exists faceapp;

use faceapp;

create table if not exists Post(		
	id int not null primary key auto_increment,
	data_post datetime,
    conteudo varchar(500) not null,
    post enum('Musica','Politica','Receita'),
    usu int not null
);

create table if not exists Usuario(	
	id int auto_increment primary key,
	nome varchar(200) not null,
    musica int not null,
    receita int not null,
    politica int not null
);


alter table Post 
	add foreign key(usu) references Usuario(id);
    
    
insert INTO Usuario(nome,musica,receita,politica)
	values('Eduarda',0,0,0);
    
select * from Usuario;
    
select * from Post;

